<?
include_once "base.php";
include_once "phpQuery/phpQuery.php";

set_time_limit(0);
ini_set("max_execution_time", "0");

function getUrl($url){
	$ch=curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_TIMEOUT, 10);
	$output=curl_exec($ch);
	curl_close($ch);
	return $output;
}
$info=array();
$j=0;
for ($i=1; $i <=20 ; $i++) {
	$listData=getUrl("https://kikfriends.io/browse/latest-kik-users?page={$i}");
	$pattern='/<div class="row">(.*?)<ul class="pagination list-unstyled text-center"/mis';
	preg_match($pattern,$listData,$result);
	$data=explode('</div>', $result[0]);
	$datas=array();
	foreach ($data as $val) {
		if(!ctype_space($val)){
			array_push($datas, $val);
		}
	}
	
	foreach ($datas as $v) {
		$html=phpQuery::newDocument($v);
		$person=explode(' ', pq(".reduced-em")->text());
		if((pq(".preview-title")->text())&&($person[0])){
			$info[$j]['name']=pq(".preview-title")->text();
			$info[$j]['headimg']=pq("img")->attr('src');
			$info[$j]['age']=$person[0];
			$info[$j]['gender']=$person[count($person)-1];
			$j++;
		}
	}

}
	// var_dump($info);
	$k=6319;
	foreach ($info as $v) {
		if($v['gender']=='girl'){
			$v['gender']='2';
		}else{
			$v['gender']='1';
		}

		$string .="({$k},".$v['age'].",'".$v['name']."',".$v['gender'].",'".$v['headimg']."','".$v['headimg']."'),";
		$k++;
	}
	$string=rtrim($string,',');
	$sql="insert into account_info (id, age , name, gender, headimg, photo) values {$string}";

	echo $sql;

	// $ret=send_execute_sql($sql,$res,0);
?>
